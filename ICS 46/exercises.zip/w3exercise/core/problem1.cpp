#include "ArrayList.hpp"

// time complexity: O(1), since we are just changing the pointer of the ArrayList which will take a constant time, not creating a new set of elements
ArrayList::ArrayList(ArrayList&& a)
{
    items = a.items;
    delete[] a.items;
    sz = a.sz;
    cap = a.cap;
}

// time complexity: O(1), since we are just changing the pointer without modifying the internal of elements
ArrayList& ArrayList::operator=(ArrayList&& a)
{
    if (this != &a)
    {
        sz = a.sz;
        cap = a.cap;
        delete[] items;
        items = a.items;
        delete[] a.items;
    }
    return *this;
    
}