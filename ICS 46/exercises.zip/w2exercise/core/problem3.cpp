#include <random>
#include <vector>
#include <map>

std::vector<unsigned int> countRandomFrequencies(
    const std::vector<unsigned int> weights,
    unsigned int count) {
        std::random_device d;
        std::default_random_engine engine{d()};
        std::discrete_distribution<unsigned int> dist{weights.begin(), weights.end()};
        std::map<int, int> map;
        std::vector<unsigned int> ans;
        for (int i = 0; i <= count; i++)
        {
            map[dist(engine)]++;
        }
        std::map<int, int>::iterator loop = map.begin();
        while (loop != map.end())
        {
            ans.push_back(loop->second);
            loop++;
        }
        return ans;
    }