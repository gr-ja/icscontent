// main.cpp
//
// ICS 46 Spring 2020
// Project #5: Rock and Roll Stops the Traffic
//
// This is the program's main() function, which is the entry point for your
// console user interface.

#include "Digraph.hpp"
#include "InputReader.hpp"
#include "RoadMapReader.hpp"
#include "RoadMapWriter.hpp"
#include "RoadSegment.hpp"
#include "Trip.hpp"
#include "TripMetric.hpp"
#include "TripReader.hpp"
#include <iomanip>
#include <iostream>

void output(double times)
{
    int hours = times/3600;
	int mins = (times-hours*3600)/60;
	double sec = times-hours*3600-mins*60;

	if(hours == 0)
	{
		if(mins == 0)
		{
			std::cout<< "total time: "<< std::fixed 
            << std::setprecision(1) <<  sec  <<" secs";
		}
		else
		{
			std::cout<< "total time: "<< mins 
            << " mins " << std::fixed 
            << std::setprecision(1) <<  sec << " secs";
		}

	}
	else
	{
		std::cout<< "total time: "<< hours <<" hrs " 
        << mins <<" mins " << std::fixed 
        << std::setprecision(1) << sec << " secs";
	}
}

std::function<double(RoadSegment)> miles = [](const RoadSegment roadM)
{
    return roadM.miles;
};

std::function<double(RoadSegment)> times = [](const RoadSegment roadM)
{
    return roadM.miles/roadM.milesPerHour * 3600;
};

int main()
{
    InputReader in(std::cin);
    RoadMapReader rmr;
    RoadMap rm = rmr.readRoadMap(in);
    TripReader tr;
    std::vector<Trip> tps = tr.readTrips(in);

    if (!rm.isStronglyConnected())
	{
		std::cout << "Disconnected roads";
		return 0;
	}

    for (int i = 0; i < tps.size(); ++i)
	{

		std::vector<int> roadFile;
		roadFile.push_back(tps[i].endVertex);
		int curr = tps[i].endVertex;
		if (tps[i].metric == TripMetric::Time)
		{
			std::cout << "Shortest driving time from " << std::fixed 
            << std::setprecision(1) << rm.vertexInfo(tps[i].startVertex) 
            << " to " << rm.vertexInfo(tps[i].endVertex) << std::endl;

			std::map<int, int> shortp = rm.findShortestPaths(tps[i].startVertex, times);
			double sumTime = 0.00;
			while (1)
			{
				roadFile.push_back(shortp.at(curr));
				curr = shortp.at(curr);
				if (curr == tps[i].startVertex)
                {
					break;
                }
			}
			
			int fromVertex = roadFile.back();
			std::cout << "  Begin at " << rm.vertexInfo(fromVertex) << std::endl;
			roadFile.pop_back();

			while (roadFile.size())
			{
				int toVertex = roadFile.back();
				double time = times(rm.edgeInfo(fromVertex, toVertex));
				std::cout << "  Continue to " << std::fixed 
                << std::setprecision(1) << rm.vertexInfo(toVertex) 
                << " (" << rm.edgeInfo(fromVertex, toVertex).miles 
                << " miles @ " << std::fixed << std::setprecision(1) 
                << rm.edgeInfo(fromVertex, toVertex).milesPerHour << "mph = ";
				output(time);
				std::cout << ")" << std::endl;
				sumTime += time;
				fromVertex = toVertex;
				roadFile.pop_back();
			}
			std::cout << "Total time: ";
			output(sumTime);
			std::cout << std::endl;
		}
		else
		{


			std::cout << "Shortest distance from " << rm.vertexInfo(tps[i].startVertex) 
            << " to " << rm.vertexInfo(tps[i].endVertex) << std::endl;
			std::map<int, int> shortp = rm.findShortestPaths(tps[i].startVertex, miles);
			double sumMiles = 0.00;
			while (1)
			{
				roadFile.push_back(shortp.at(curr));
				curr = shortp.at(curr);
				if (curr == tps[i].startVertex)
					break;
			}

			int fromVertex = roadFile.back();
			std::cout << "  Begin at " << rm.vertexInfo(fromVertex) << std::endl;
			roadFile.pop_back();

			while (roadFile.size())
			{   
				int toVertex = roadFile.back();
				std::cout << "  Continue to " << rm.vertexInfo(toVertex) 
                << " (" << std::fixed << std::setprecision(1) 
                << rm.edgeInfo(fromVertex, toVertex).miles << " miles)" << std::endl;
				sumMiles += rm.edgeInfo(fromVertex, toVertex).miles;
				fromVertex = toVertex;
				roadFile.pop_back();
			}
			std::cout << "Total distance: " << std::fixed << std::setprecision(1) 
            << sumMiles << " miles" << std::endl;
		}
		std::cout << std::endl;
	}
    return 0;
}