#include "OthelloAI.hpp"
#include <vector>

namespace deyuq
{
    class NoOthelloAI: public OthelloAI
    {
    public:
        std::pair <int, int> chooseMove(const OthelloGameState& state);
    private:
        std::vector<std::pair<int,int>> validMove(std::unique_ptr<OthelloGameState> s);
        int search(std::unique_ptr<OthelloGameState> s, int depth, bool myTurn = false);
        int eval(std::unique_ptr<OthelloGameState> s, bool myTurn);
    };
}