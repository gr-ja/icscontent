// AVLSet.hpp
//
// ICS 46 Spring 2020
// Project #4: Set the Controls for the Heart of the Sun
//
// An AVLSet is an implementation of a Set that is an AVL tree, which uses
// the algorithms we discussed in lecture to maintain balance every time a
// new element is added to the set.  The balancing is actually optional,
// with a bool parameter able to be passed to the constructor to explicitly
// turn the balancing on or off (on is default).  If the balancing is off,
// the AVL tree acts like a binary search tree (e.g., it will become
// degenerate if elements are added in ascending order).
//
// You are not permitted to use the containers in the C++ Standard Library
// (such as std::set, std::map, or std::vector) to store the information
// in your data structure.  Instead, you'll need to implement your AVL tree
// using your own dynamically-allocated nodes, with pointers connecting them,
// and with your own balancing algorithms used.

#ifndef AVLSET_HPP
#define AVLSET_HPP

#include <functional>
#include "Set.hpp"



template <typename ElementType>
class AVLSet : public Set<ElementType>
{
public:
    // A VisitFunction is a function that takes a reference to a const
    // ElementType and returns no value.
    using VisitFunction = std::function<void(const ElementType&)>;

public:
    // Initializes an AVLSet to be empty, with or without balancing.
    explicit AVLSet(bool shouldBalance = true);

    // Cleans up the AVLSet so that it leaks no memory.
    ~AVLSet() noexcept override;

    // Initializes a new AVLSet to be a copy of an existing one.
    AVLSet(const AVLSet& s);

    // Initializes a new AVLSet whose contents are moved from an
    // expiring one.
    AVLSet(AVLSet&& s) noexcept;

    // Assigns an existing AVLSet into another.
    AVLSet& operator=(const AVLSet& s);

    // Assigns an expiring AVLSet into another.
    AVLSet& operator=(AVLSet&& s) noexcept;


    // isImplemented() should be modified to return true if you've
    // decided to implement an AVLSet, false otherwise.
    bool isImplemented() const noexcept override;


    // add() adds an element to the set.  If the element is already in the set,
    // this function has no effect.  This function always runs in O(log n) time
    // when there are n elements in the AVL tree.
    void add(const ElementType& element) override;


    // contains() returns true if the given element is already in the set,
    // false otherwise.  This function always runs in O(log n) time when
    // there are n elements in the AVL tree.
    bool contains(const ElementType& element) const override;


    // size() returns the number of elements in the set.
    unsigned int size() const noexcept override;


    // height() returns the height of the AVL tree.  Note that, by definition,
    // the height of an empty tree is -1.
    int height() const noexcept;


    // preorder() calls the given "visit" function for each of the elements
    // in the set, in the order determined by a preorder traversal of the AVL
    // tree.
    void preorder(VisitFunction visit) const;


    // inorder() calls the given "visit" function for each of the elements
    // in the set, in the order determined by an inorder traversal of the AVL
    // tree.
    void inorder(VisitFunction visit) const;


    // postorder() calls the given "visit" function for each of the elements
    // in the set, in the order determined by a postorder traversal of the AVL
    // tree.
    void postorder(VisitFunction visit) const;


private:
    // You'll no doubt want to add member variables and "helper" member
    // functions here.

    // a structure of node in the tree
    // have content and pointer of its left and right nodes
    struct Node
    {
        ElementType content;
        Node* right;
        Node* left;
    };

    bool balance;
    Node* root;
    Node* act;
    int si;

    void LL(Node*& node);
    void RR(Node*& node);
    void LR(Node*& node);
    void RL(Node*& node);

    void deletion(Node* treeNode);
    void copy(Node* target, Node*& node);
    void addRecur(const ElementType& content, Node*& node); // iteration?
    bool containsRecur(const ElementType& element, Node* node) const; // iteration?
    int getHeight(Node* node) const;
    void preorderRecur(VisitFunction visit, Node* node) const;
    void inorderRecur(VisitFunction visit, Node* node) const;
    void postorderRecur(VisitFunction visit, Node* node) const;
};


template <typename ElementType>
AVLSet<ElementType>::AVLSet(bool shouldBalance)
{
    si = 0;
    root = nullptr;
    balance = shouldBalance;
}


template <typename ElementType>
AVLSet<ElementType>::~AVLSet() noexcept
{
    deletion(root);
}


template <typename ElementType>
AVLSet<ElementType>::AVLSet(const AVLSet& s)
{
    copy(s.root,root);
    si = s.si;
}


template <typename ElementType>
AVLSet<ElementType>::AVLSet(AVLSet&& s) noexcept
{
    copy(s.root,root);
    si = s.si;
    deletion(s.root);
}


template <typename ElementType>
AVLSet<ElementType>& AVLSet<ElementType>::operator=(const AVLSet& s)
{
    if (this!=&s)
    {
        si = s.si;
        deletion(this->root);
        copy(s.root,root);
    }
    return *this;
}


template <typename ElementType>
AVLSet<ElementType>& AVLSet<ElementType>::operator=(AVLSet&& s) noexcept
{
    if (this!=&s)
    {
        si = s.si;
        deletion(this->root);
        copy(s.root,root);
        deletion(s.root);
    }
    return *this;
}


template <typename ElementType>
bool AVLSet<ElementType>::isImplemented() const noexcept
{
    return true;
}


template <typename ElementType>
void AVLSet<ElementType>::add(const ElementType& element)
{
    if (contains(element))
    {
        return;
    }
    else
    {
        addRecur(element, root);
        si++;
    }
}


template <typename ElementType>
bool AVLSet<ElementType>::contains(const ElementType& element) const
{
    return containsRecur(element, root);
}


template <typename ElementType>
unsigned int AVLSet<ElementType>::size() const noexcept
{
    return si;
}


template <typename ElementType>
int AVLSet<ElementType>::height() const noexcept
{
    return getHeight(root);
}

template <typename ElementType>
void AVLSet<ElementType>::preorder(VisitFunction visit) const
{
    preorderRecur(visit,root);
}


template <typename ElementType>
void AVLSet<ElementType>::inorder(VisitFunction visit) const
{
    inorderRecur(visit,root);
}


template <typename ElementType>
void AVLSet<ElementType>::postorder(VisitFunction visit) const
{
    postorderRecur(visit,root);
}

template <typename ElementType>
void AVLSet<ElementType>::deletion(Node* node)
{
    if (node == nullptr)
    {
        return;
    }
    deletion(node->left);
    deletion(node->right);
    delete node;
}

template <typename ElementType>
void AVLSet<ElementType>::copy(Node* target, Node*& node)
{
    if (target == nullptr)
    {
        node = nullptr;
    }
    else
    {
        node = new Node{target->content};
        if (target->left == nullptr && target->right == nullptr)
        {
            return;
        }
        else
        {
            copy(target->left, node->left);
            copy(target->right, node->right);
        }
    }
}

template <typename ElementType>
bool AVLSet<ElementType>::containsRecur(const ElementType& element, Node* node) const
{
    if (node == nullptr)
    {
        return false;
    }
    else if (node->content == element)
    {
        return true;
    }
    else if (node->content > element)
    {
        return containsRecur(element, node->left);
    }
    else
    {
        return containsRecur(element, node->right);
    }
}

template <typename ElementType>
void AVLSet<ElementType>::addRecur(const ElementType& content, Node*& node) // simplify?
{
    if (balance == true)
    {
        if (node == nullptr)
        {
            node = new Node{content};
        }
        else if (content > node->content)
        {
            addRecur(content, node->right);
            if (getHeight(node->right)-getHeight(node->left) == 2)
            {
                if (content > node->right->content)
                {
                    RR(node);
                }
                else
                {
                    LR(node);
                }
            }
        }
        else
        {
            addRecur(content, node->left);
            if (getHeight(node->left)-getHeight(node->right) == 2)
            {
                if (content < node->left->content)
                {
                    LL(node);
                }
                else
                {
                    RL(node);
                }
            }
        }
    }
    else
    {
        if (node == nullptr)
        {
            node = new Node{content};
        }
        else if (content < node->content)
        {
            addRecur(content, node->left);
        }
        else
        {
            addRecur(content, node->right);
        }
    }
}

template <typename ElementType>
int AVLSet<ElementType>::getHeight(Node* node) const
{
    if (node == nullptr)
    {
        return -1;
    }
    int leftH = getHeight(node->left);
    int rightH = getHeight(node->right);
    if(leftH > rightH)
    {
        return leftH+1;
    }
    else
    {
        return rightH+1;   
    }
}

template <typename ElementType>
void AVLSet<ElementType>::LL(Node*& node)
{
    Node* temp;

    temp = node->left;
    node->left = temp->right;
    temp->right = node;
    node = temp;
}

template <typename ElementType>
void AVLSet<ElementType>::RR(Node*& node)
{
    Node* temp;

    temp = node->right;
    node->right = temp->left;
    temp->left = node;
    node = temp;
}

template <typename ElementType>
void AVLSet<ElementType>::RL(Node*& node)
{
    RR(node->left);
    LL(node);
}

template <typename ElementType>
void AVLSet<ElementType>::LR(Node*& node)
{
    LL(node->right);
    RR(node);
}

template <typename ElementType>
void AVLSet<ElementType>::preorderRecur(VisitFunction visit, Node* node) const
{
    if(node == nullptr)
        return;
    visit(node->content);
    preorderRecur(visit, node->left);
    preorderRecur(visit, node->right);
}


template <typename ElementType>
void AVLSet<ElementType>::inorderRecur(VisitFunction visit, Node* node) const
{
    if(node == nullptr)
        return;
    inorderRecur(visit, node->left);
    visit(node->content);
    inorderRecur(visit, node->right);
}


template <typename ElementType>
void AVLSet<ElementType>::postorderRecur(VisitFunction visit, Node* node) const
{
    if(node == nullptr)
        return;
    postorderRecur(visit, node->left);
    postorderRecur(visit, node->right);
    visit(node->content);
}

#endif // AVLSET_HPP

