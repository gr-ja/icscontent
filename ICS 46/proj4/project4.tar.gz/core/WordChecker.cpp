// WordChecker.cpp
//
// ICS 46 Spring 2020
// Project #4: Set the Controls for the Heart of the Sun
//
// Replace and/or augment the implementations below as needed to meet
// the requirements.

#include "WordChecker.hpp"



WordChecker::WordChecker(const Set<std::string>& words)
    : words{words}
{
    
}


bool WordChecker::wordExists(const std::string& word) const
{
    return words.contains(word);
}

std::vector<std::string> WordChecker::findSuggestions(const std::string& word) const
{
    std::vector<std::string> ans;
    std::string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    int i = 0;
    while (i < word.size()-1)
    {
        std::string temp = word;
        std::swap(temp[i], temp[i+1]);
        if (wordExists(temp) && std::find(ans.begin(), ans.end(), temp) == ans.end())
        {
            ans.push_back(temp);
        }
        i++;
    }
    i = 0;
    while (i < word.size()+1)
    {
        int j = 0;
        while (j < alphabet.size())
        {
            std::string temp = word;
            temp.insert(i, alphabet.substr(j,1));
            if (wordExists(temp) && std::find(ans.begin(), ans.end(), temp) == ans.end())
            {
                ans.push_back(temp);
            }
            j++;
        }
        i++;
    }
    i = 0;
    while (i < word.size())
    {
        std::string temp = word;
        temp.erase(i,1);
        if (wordExists(temp) && std::find(ans.begin(), ans.end(), temp) == ans.end())
        {
            ans.push_back(temp);
        }
        i++;
    }
    i = 0;
    while (i < word.size())
    {
        std::string temp = word;
        int j = 0;
        while (j < alphabet.size())
        {
            temp.replace(i,1,alphabet.substr(j,1));
            if (wordExists(temp) && std::find(ans.begin(), ans.end(), temp) == ans.end())
            {
                ans.push_back(temp);
            }
            j++;
        }
        i++;
    }
    i = 0;
    while (i < word.size())
    {
        std::string prev = word.substr(0,i);
        std::string next = word.substr(i);
        if (wordExists(prev) && wordExists(next) && std::find(ans.begin(), ans.end(), prev+" "+next) == ans.end())
        {
            ans.push_back(prev+" "+next);
        }
        i++;
    }

    return ans;
}

